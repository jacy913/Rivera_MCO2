/**
 * Driver class for running GUI.
 */
public class StartApp {
    public static void main(String[] args) {
        // Create a new VendingMachine instance
        VendingMachine vendingMachine = new VendingMachine();

        // Create a new VendingMachineController instance with the VendingMachine
        VendingMachineController controller = new VendingMachineController(vendingMachine);
    }
}
