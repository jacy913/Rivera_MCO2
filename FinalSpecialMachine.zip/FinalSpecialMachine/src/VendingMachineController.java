import javax.swing.*;
import java.util.ArrayList;

/**
 * This class is responsible for controlling the logic and events that occur during the GUi process.
 */
public class VendingMachineController {
    private VendingMachine vendingMachine;
    private View gui;

    /**
     * Constructs a VendingMachineController object for orchestrating the GUI events.
     * @param vendingMachine Accepts a vending machine instance.
     */
    public VendingMachineController(VendingMachine vendingMachine) {
        this.vendingMachine = vendingMachine;
        this.gui = new View(this);
    }

    /**
     * This method controls the displaying and refreshing of the menu in the GUI.
     * @return
     */
    public String displayInventory() {
        String inventoryText = vendingMachine.displayInventory();
        return inventoryText;
    }

    /**
     * This method handles the logic of inserting money in the machine through the GUI.
     */
    public void insertMoneyLogic() {

        String[] denominationInput = {"1", "5", "10", "20"};
        String selectedDenomination = (String) JOptionPane.showInputDialog(
                null,
                "Select the denomination:",
                "Insert Money",
                JOptionPane.PLAIN_MESSAGE,
                null,
                denominationInput,
                denominationInput[0]
        );

        if (selectedDenomination == null) {
            return;
        }

        if (denominationInput != null) {
            String billsInput = JOptionPane.showInputDialog(null, "Enter the number of bills:", "Insert Money", JOptionPane.PLAIN_MESSAGE);

            if (billsInput != null) {
                try {
                    int denomination = Integer.parseInt(selectedDenomination);
                    int bills = Integer.parseInt(billsInput);

                    Money money = new Money(denomination, bills);

                    vendingMachine.insertMoney(money);

                    double moneyOutput = vendingMachine.getTotalBalance();
                    gui.updateInsertedAmountLabel(moneyOutput);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid integers for denomination and bills.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    /**
     * This method handles the logic when purchasing an item through the GUI.
     */
    public void purchaseItemLogic() {
        ArrayList<String> itemNames = new ArrayList<>();
        ArrayList<Item> availableItems = Customizables.getAvailableItems();
        for (Item item : availableItems) {
            itemNames.add(item.getName());
        }

        String[] itemNamesArray = itemNames.toArray(new String[0]);
        JComboBox<String> itemNameDropdown = new JComboBox<>(itemNamesArray);

        int result = JOptionPane.showConfirmDialog(null, itemNameDropdown, "Select Item to Purchase", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String selectedName = (String) itemNameDropdown.getSelectedItem();

            String quantityInput = JOptionPane.showInputDialog(null, "Enter the quantity:", "Purchase Item", JOptionPane.PLAIN_MESSAGE);
            if (quantityInput == null) {
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityInput);

                Item selectedItem = null;
                for (Item availableItem : availableItems) {
                    if (availableItem.getName().equalsIgnoreCase(selectedName)) {
                        selectedItem = availableItem;
                        break;
                    }
                }

                if (selectedItem != null && vendingMachine.getRemainingQuantity(selectedItem) >= quantity) {
                    Transaction purchaseTransaction = vendingMachine.purchaseIngredient(selectedItem, quantity);
                    gui.updateInsertedAmountLabel(vendingMachine.getBalance());

                    if (purchaseTransaction != null) {
                        JOptionPane.showMessageDialog(null, "Purchase successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Item not found or insufficient quantity.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer for quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * This method handles the logic when customizing and purchasing an item through the GUI.
     */
    public void customizeItemLogic() {
        ArrayList<Customizables> customizablesList = Customizables.getAvailableCustomizables();
        String[] customizableOptions = new String[customizablesList.size()];
        for (int i = 0; i < customizablesList.size(); i++) {
            Customizables customizable = customizablesList.get(i);
            customizableOptions[i] = (i + 1) + ". " + customizable.getName();
        }

        String selectedCustomizableOption = (String) JOptionPane.showInputDialog(
                null,
                "Available Customizable Products:",
                "Customize Item",
                JOptionPane.PLAIN_MESSAGE,
                null,
                customizableOptions,
                customizableOptions[0]
        );

        if (selectedCustomizableOption == null) {
            return;
        }

        int productChoice = Integer.parseInt(selectedCustomizableOption.split("\\.")[0]) - 1;
        if (productChoice < 0 || productChoice >= customizablesList.size()) {
            JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Customizables selectedCustomizable = customizablesList.get(productChoice);

        int addIngredientsChoice = JOptionPane.showConfirmDialog(
                null,
                "Do you want to add additional ingredients?",
                "Customize Item",
                JOptionPane.YES_NO_OPTION
        );

        if (addIngredientsChoice == JOptionPane.YES_OPTION) {
            ArrayList<Item> availableItems = Customizables.getAvailableItems();
            String[] ingredientOptions = new String[availableItems.size()];
            for (int i = 0; i < availableItems.size(); i++) {
                Item availableItem = availableItems.get(i);
                ingredientOptions[i] = (i + 1) + ". " + availableItem.getName() + " (Price: $" + availableItem.getPrice() + ", Calories: " + availableItem.getCalories() + " cal)";
            }

            ArrayList<Item> selectedItems = new ArrayList<>();
            ArrayList<Integer> quantities = new ArrayList<>();

            while (true) {
                String selectedIngredientOption = (String) JOptionPane.showInputDialog(
                        null,
                        "Available Ingredients for Customization:",
                        "Customize Item",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        ingredientOptions,
                        ingredientOptions[0]
                );

                if (selectedIngredientOption == null || selectedIngredientOption.equals("0")) {
                    break;
                }

                int ingredientChoice = Integer.parseInt(selectedIngredientOption.split("\\.")[0]) - 1;
                if (ingredientChoice < 0 || ingredientChoice >= availableItems.size()) {
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                Item selectedIngredient = availableItems.get(ingredientChoice);

                String quantityInput = JOptionPane.showInputDialog(null, "Enter the quantity of " + selectedIngredient.getName() + " you want to include:", "Customize Item", JOptionPane.PLAIN_MESSAGE);
                if (quantityInput == null) {
                    continue;
                }

                try {
                    int quantity = Integer.parseInt(quantityInput);
                    if (quantity > 0) {
                        selectedItems.add(selectedIngredient);
                        quantities.add(quantity);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer for quantity.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

            for (int i = 0; i < selectedItems.size(); i++) {
                Item selectedIngredient = selectedItems.get(i);
                int quantity = quantities.get(i);
                selectedCustomizable.addItem(selectedIngredient.getName(), quantity);
            }
        }

        ArrayList<Item> availableItems = selectedCustomizable.getItems();
        String[] itemOptions = new String[availableItems.size()];
        for (int i = 0; i < availableItems.size(); i++) {
            Item item2 = availableItems.get(i);
            itemOptions[i] = (i + 1) + ". " + item2.getName() + " (Price: $" + item2.getPrice() + ", Calories: " + item2.getCalories() + " cal)";
        }

        ArrayList<Item> selectedItems = new ArrayList<>();
        ArrayList<Integer> quantities = new ArrayList<>();

        for (Item item3 : availableItems) {
            String quantityInput = JOptionPane.showInputDialog(null, "Enter the quantity of " + item3.getName() + " you want to include:", "Customize Item", JOptionPane.PLAIN_MESSAGE);
            if (quantityInput == null) {
                continue;
            }

            try {
                int quantity = Integer.parseInt(quantityInput);
                if (quantity > 0) {
                    selectedItems.add(item3);
                    quantities.add(quantity);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer for quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        vendingMachine.prepareCustomizableProduct(selectedCustomizable, selectedItems, quantities);

        int purchaseChoice = JOptionPane.showConfirmDialog(
                null,
                "Do you want to purchase this customizable product?",
                "Customize Item",
                JOptionPane.YES_NO_OPTION
        );

        if (purchaseChoice == JOptionPane.YES_OPTION) {
            ArrayList<Purchaseable> itemsToPurchase = new ArrayList<>(selectedItems);
            itemsToPurchase.add(selectedCustomizable);
            Transaction purchaseTransaction = vendingMachine.purchaseItem(itemsToPurchase);
            gui.updateInsertedAmountLabel(vendingMachine.getBalance());
            if (purchaseTransaction != null) {
                JOptionPane.showMessageDialog(null, "Purchase successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                purchaseTransaction.printReceipt();
            }
        }
    }

    /**
     * This method handles the exiting procedure through the GUi, as well as the printing of receipts.
     * @return
     */
    public String receiptLogic() {
        String receiptList = new String(vendingMachine.getTransactionReceipts());
        return receiptList;
    }

    /**
     * This method handles the maintenance menu when accessed through the GUI. It uses a switch case to navigate through tasks.
     */
    public void maintenanceMenuLogic() {
        gui.updateInsertedAmountLabel(vendingMachine.getVendorCash());
        String[] maintenanceOptions = {"Add item", "Restock items", "Change item price", "Collect revenue", "Replenish Money"};
        String selectedOption = (String) JOptionPane.showInputDialog(null, "Choose an action:", "Maintenance Menu", JOptionPane.PLAIN_MESSAGE, null, maintenanceOptions, maintenanceOptions[0]);

        if (selectedOption == null) {
            return;
        }

        switch (selectedOption) {
            case "Add item":
                addItemLogic();
                break;

            case "Restock items":
                restockItemsLogic();
                break;

            case "Change item price":
                changeItemPriceLogic();
                break;

            case "Collect revenue":
                vendingMachine.collectRevenue();
                JOptionPane.showMessageDialog(null, "Collected $" + vendingMachine.getVendorCash() + " in Revenue!", "Error", JOptionPane.PLAIN_MESSAGE);
                break;

            case "Replenish Money":
                replenishMoneyLogic();
                break;

            default:
                break;
        }
    }

    /**
     * This method handles the logic when restocking an item in the machine through the GUI.
     */
    public void restockItemsLogic() {
        ArrayList<String> itemNames = new ArrayList<>();
        ArrayList<Item> availableItems = Customizables.getAvailableItems();
        for (Item item : availableItems) {
            itemNames.add(item.getName());
        }

        String[] itemNamesArray = itemNames.toArray(new String[0]);
        JComboBox<String> itemNameDropdown = new JComboBox<>(itemNamesArray);

        int result = JOptionPane.showConfirmDialog(null, itemNameDropdown, "Select Item to Restock", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String selectedName = (String) itemNameDropdown.getSelectedItem();

            String quantityInput = JOptionPane.showInputDialog(null, "Enter the quantity to restock for " + selectedName + ":", "Restock Items", JOptionPane.PLAIN_MESSAGE);

            if (quantityInput == null) {
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityInput);

                Item restockItem = null;
                for (Item item : availableItems) {
                    if (item.getName().equalsIgnoreCase(selectedName)) {
                        restockItem = item;
                        break;
                    }
                }

                if (restockItem != null) {
                    vendingMachine.restockItems(restockItem, quantity);
                    JOptionPane.showMessageDialog(null, "Item " + selectedName + " restocked successfully.", "Restock Items", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Item " + selectedName + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer for quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * This method handles the logic when changing the price of an existing item through the GUI.
     */
    public void changeItemPriceLogic() {
        ArrayList<String> itemNames = new ArrayList<>();
        ArrayList<Item> availableItems = Customizables.getAvailableItems();
        for (Item item : availableItems) {
            itemNames.add(item.getName());
        }

        String[] itemNamesArray = itemNames.toArray(new String[0]);
        JComboBox<String> itemNameDropdown = new JComboBox<>(itemNamesArray);

        int result = JOptionPane.showConfirmDialog(null, itemNameDropdown, "Select Item to Change Price", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String selectedName = (String) itemNameDropdown.getSelectedItem();

            String newPriceInput = JOptionPane.showInputDialog(null, "Enter the new price for " + selectedName + ":", "Change Item Price", JOptionPane.PLAIN_MESSAGE);

            if (newPriceInput == null) {
                return;
            }

            try {
                double newPrice = Double.parseDouble(newPriceInput);

                Item itemToChangePrice = null;
                for (Item item : availableItems) {
                    if (item.getName().equalsIgnoreCase(selectedName)) {
                        itemToChangePrice = item;
                        break;
                    }
                }

                if (itemToChangePrice != null) {
                    itemToChangePrice.setPrice(newPrice);
                    JOptionPane.showMessageDialog(null, "Price of " + selectedName + " changed to $" + newPrice, "Change Item Price", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Item " + selectedName + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number for the new price.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * This method handles the replenishing of the machine's internal cash through the GUI.
     */
    public void replenishMoneyLogic() {

        String[] denominationInput = {"1", "5", "10", "20"};
        String selectedDenomination = (String) JOptionPane.showInputDialog(
                null,
                "Select the denomination:",
                "Insert Money",
                JOptionPane.PLAIN_MESSAGE,
                null,
                denominationInput,
                denominationInput[0]
        );

        if (selectedDenomination == null) {
            return;
        }

        if (denominationInput != null) {
            String billsInput = JOptionPane.showInputDialog(null, "Enter the number of bills:", "Insert Money", JOptionPane.PLAIN_MESSAGE);

            if (billsInput != null) {
                try {
                    int denomination = Integer.parseInt(selectedDenomination);
                    int bills = Integer.parseInt(billsInput);

                    Money money = new Money(denomination, bills);

                    vendingMachine.insertVendorCash(money);

                    double moneyOutput = vendingMachine.getTotalBalance();
                    JOptionPane.showConfirmDialog(null,"Stored cash in the vending machine is now $" + vendingMachine.getVendorCash(), "Success!", JOptionPane.PLAIN_MESSAGE);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid integers for denomination and bills.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    /**
     * This method handles the logic when adding a new item to be sold in the machine.
     */
    public void addItemLogic() {
        String itemNameInput = JOptionPane.showInputDialog(null, "Enter the name of the item:", "Add Item",
                JOptionPane.PLAIN_MESSAGE);
        if (itemNameInput == null) {
            return;
        }

        String priceInput = JOptionPane.showInputDialog(null, "Enter the price of the item:", "Add Item",
                JOptionPane.PLAIN_MESSAGE);
        if (priceInput == null) {
            return;
        }

        String caloriesInput = JOptionPane.showInputDialog(null, "Enter the caloric yield of the item:", "Add Item",
                JOptionPane.PLAIN_MESSAGE);
        if (caloriesInput == null) {
            return;
        }

        String quantityInput = JOptionPane.showInputDialog(null, "Enter the quantity:", "Add Item",
                JOptionPane.PLAIN_MESSAGE);
        if (quantityInput == null) {
            return;
        }

        try {
            double price = Double.parseDouble(priceInput);
            double calories = Double.parseDouble(caloriesInput);
            int quantity = Integer.parseInt(quantityInput);

            int confirmResult = JOptionPane.showConfirmDialog(null, "Add the item to available items?", "Confirmation",
                    JOptionPane.YES_NO_OPTION);
            if (confirmResult == JOptionPane.YES_OPTION) {
                Item newItem = new Item(itemNameInput, price, calories, quantity);
                Customizables.addNewItem(newItem);

                JOptionPane.showMessageDialog(null, itemNameInput + " added successfully.", "Success!",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                    "Invalid input. Please enter a valid number for price, caloric yield, and quantity.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method handles the returning of change through the GUI.
     */
    public void returnChangeLogic() {
        double remainingBalance = vendingMachine.getBalance();

        if (remainingBalance > 0) {
            StringBuilder changeMessage = new StringBuilder("Returning your inserted money:\n $" + remainingBalance + "\n");
            ArrayList<Money> moneyList = Money.createMoneyList();

            for (int i = moneyList.size() - 1; i >= 0; i--) {
                Money money = moneyList.get(i);
                int denomination = money.getDenomination();
                int numBills = (int) (remainingBalance / denomination);

                if (numBills > 0) {
                    changeMessage.append("Denomination: $").append(denomination).append(" Bills: ").append(numBills).append("\n");
                    remainingBalance -= numBills * denomination;
                }
            }

            JOptionPane.showMessageDialog(null, changeMessage.toString(), "Change Returned", JOptionPane.INFORMATION_MESSAGE);

            vendingMachine.setBalance(0);
        }
    }

    public VendingMachine getVendingMachine() {
        return vendingMachine;
    }
}
