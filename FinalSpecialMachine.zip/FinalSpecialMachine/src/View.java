import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class is responsible for the formatting, placement, and aesthetics of the GUI.
 */
public class View {
    private JFrame frame;
    private JTextArea textArea;
    private JButton viewMenuButton;
    private JButton returnButton;
    private JButton insertMoneyButton;
    private JButton purchaseItemButton;
    private JButton customizeItemButton;
    private JButton receiptButton;
    private JButton maintenanceMenuButton;

    private JLabel insertedAmountLabel;

    private VendingMachineController controller;

    /**
     * Constructs a View object to design the GUI.
     * @param controller Accepts a VendingMachineController object.
     */

    public View(VendingMachineController controller) {
        this.controller = controller;
        createGUI();
    }

    /**
     * This method is responsible for creating what the GUI will look like upon launch.
     */
    private void createGUI() {
        frame = new JFrame("Vending Machine");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Osaka", Font.BOLD, 20));

        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane);

        viewMenuButton = new JButton("View Menu");
        viewMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showMenu();
            }
        });

        returnButton = new JButton("Back to Main");
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainMenu();
            }
        });

        insertMoneyButton = new JButton("Insert Money");
        insertMoneyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertMoney();
            }
        });

        purchaseItemButton = new JButton("Purchase Item");
        purchaseItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseItem();
            }
        });

        customizeItemButton = new JButton("Customize Item");
        customizeItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customizeItem();
            }
        });

        receiptButton = new JButton("Exit");
        receiptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                receipt();
            }
        });

        maintenanceMenuButton = new JButton("Maintenance");
        maintenanceMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                maintenanceMenu();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 1;
        gbc.gridy = 0;
        buttonPanel.add(viewMenuButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonPanel.add(returnButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        buttonPanel.add(insertMoneyButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        buttonPanel.add(purchaseItemButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        buttonPanel.add(customizeItemButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        buttonPanel.add(receiptButton, gbc);

        gbc.gridx = -1;
        gbc.gridy = 0;
        buttonPanel.add(maintenanceMenuButton, gbc);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        mainMenu();

        insertedAmountLabel = new JLabel("Total Inserted Amount: $0.00");
        frame.add(insertedAmountLabel, BorderLayout.NORTH);

        frame.setVisible(true);
    }

    /**
     * Updates the label placed at the top which holds the balance of the user.
     * @param amount
     */
    public void updateInsertedAmountLabel(double amount) {
        insertedAmountLabel.setText("Total Inserted Amount: $" + String.format("%.2f", amount));
    }

    /**
     * Updates the text area displayed when navigating pages.
     * @param text Accepts a String text parameter.
     */
    public void updateTextArea(String text) {
        textArea.setText(text);
    }

    /**
     * This method is responsible for building the main menu of the vending machine.
     */
    public void mainMenu() {
        String vendingMachineText = "Vending Machine";
        updateTextArea(vendingMachineText);
        viewMenuButton.setVisible(true);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(true);
        purchaseItemButton.setVisible(true);
        customizeItemButton.setVisible(true);
        receiptButton.setVisible(true);
        maintenanceMenuButton.setVisible(true);
    }

    /**
     * This method is responsible for displaying the available items for sale.
     */
    public void showMenu() {
        updateTextArea(controller.displayInventory());
        viewMenuButton.setVisible(false);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(false);
        purchaseItemButton.setVisible(true);
        customizeItemButton.setVisible(true);
        receiptButton.setVisible(true);
        maintenanceMenuButton.setVisible(false);
    }

    /**
     * This method is responsible for building the insert money page of the machine.
     */
    public void insertMoney() {
        String moneyText = new String("Insert Money");
        updateTextArea(moneyText);

        viewMenuButton.setVisible(true);
        returnButton.setVisible(true);
        viewMenuButton.setVisible(false);
        purchaseItemButton.setVisible(false);
        customizeItemButton.setVisible(false);
        receiptButton.setVisible(false);
        maintenanceMenuButton.setVisible(false);

        controller.insertMoneyLogic();
    }

    /**
     * This method is responsible for handling the page when purchasing an item.
     */
    public void purchaseItem() {
        updateTextArea("Purchase Item");
        updateTextArea(controller.displayInventory());
        viewMenuButton.setVisible(true);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(false);
        purchaseItemButton.setVisible(false);
        customizeItemButton.setVisible(false);
        receiptButton.setVisible(false);
        maintenanceMenuButton.setVisible(false);

        if(controller.getVendingMachine().getBalance() > 0) {
            controller.purchaseItemLogic();
        }else {
            JOptionPane.showMessageDialog(null, "Balance is zero. Insert money!", "Unsuccessful!", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * This method is responsible for building the page when customizing and purchasing an item.
     */
    public void customizeItem() {
        updateTextArea("Customize Item");
        viewMenuButton.setVisible(true);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(false);
        purchaseItemButton.setVisible(false);
        customizeItemButton.setVisible(true);
        receiptButton.setVisible(false);
        maintenanceMenuButton.setVisible(false);

        if(controller.getVendingMachine().getBalance() > 0) {
            controller.customizeItemLogic();
        }else {
            JOptionPane.showMessageDialog(null, "Balance is zero. Insert money!", "Unsuccessful!", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * This method is responsible for building the exit page, where a receipt if necessary is generated and change is returned.
     */
    public void receipt() {
        updateTextArea("Receipt");
        viewMenuButton.setVisible(true);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(false);
        purchaseItemButton.setVisible(false);
        customizeItemButton.setVisible(false);
        receiptButton.setVisible(true);
        maintenanceMenuButton.setVisible(false);

        updateTextArea(controller.receiptLogic());
        controller.returnChangeLogic();

    }

    /**
     * This method is responsible for building the maintenance menu.
     */
    public void maintenanceMenu() {
        updateTextArea("Maintenance Menu");
        viewMenuButton.setVisible(false);
        returnButton.setVisible(true);
        insertMoneyButton.setVisible(false);
        purchaseItemButton.setVisible(false);
        customizeItemButton.setVisible(false);
        receiptButton.setVisible(false);

        controller.maintenanceMenuLogic();


    }
}
